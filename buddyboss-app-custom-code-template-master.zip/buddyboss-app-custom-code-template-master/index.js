export const applyCustomCode = externalCodeSetup => {
	// call custom code api here
};
